==================
Usage, Inputs and outputs
==================
Certain of the code uses an open-source software:
- FCbO <http://fcalgs.sourceforge.net/>.

A example about how to use NCFCA is as follows.


$ ./NCFCA -P0.5 -A5 -O5 -N1 input.txt output.txt


-P is the value of а for data discretization.

-A is the minimum number of time points in each negative correlation pattern.

-O is the minimum number of genes in each negative correlation pattern..

-N is the minimum number of genes in each subset of each negative correlation pattern

input.txt is gene expression data.

output.txt is the result of NCFCA from input.txt.
